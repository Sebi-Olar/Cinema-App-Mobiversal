package olarEus.app.movieapp.utils

object Constants {
    const val  BASE_URL= "https://api.themoviedb.org/3/"
    const val API_KEY = "1f1f1c19cf42d74004302d55be236459"
    const val LANGUAGE = "en-US"
    const val IMAGE_URL = "https://image.tmdb.org/t/p/w500/"
    const val IMAGE_URL_MOVIE = "https://image.tmdb.org/t/p/h632/"
    const val APPEND_TO_RESPONSE="videos"

}
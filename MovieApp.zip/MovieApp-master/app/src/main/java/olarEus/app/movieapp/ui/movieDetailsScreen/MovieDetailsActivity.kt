package olarEus.app.movieapp.ui.movieDetailsScreen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import olarEus.app.movieapp.R

class MovieDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_details)
    }
}
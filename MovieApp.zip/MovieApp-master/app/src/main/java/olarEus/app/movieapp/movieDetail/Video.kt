package olarEus.app.movieapp.movieDetail

 data class Video (
    val key:String,
    val type: String
)
package olarEus.app.movieapp.movieDetail

 data class VideoList (
    val results:List<Video>
 )